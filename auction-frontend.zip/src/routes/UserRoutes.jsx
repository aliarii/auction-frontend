import React from "react";

function UserRoutes() {
  return <div>UserRoutes</div>;
}

export default UserRoutes;
