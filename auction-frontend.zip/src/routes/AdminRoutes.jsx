import React from "react";

function AdminRoutes() {
  return <div>AdminRoutes</div>;
}

export default AdminRoutes;
