import React from "react";

function HorizontalLine() {
  return <div className="py-0.5 rounded-full bg-light-7" />;
}

export default HorizontalLine;
